typedef struct _test_struct{
    
    char name[20];
    int age;
    char group[20];

} test_struct_t;


typedef struct result_struct_{

    unsigned int c;

} result_struct_t;
