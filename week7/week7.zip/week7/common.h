typedef struct _test_struct{
    
    char string[5];

} test_struct_t;


typedef struct result_struct_{

    char string[5];

} result_struct_t;
